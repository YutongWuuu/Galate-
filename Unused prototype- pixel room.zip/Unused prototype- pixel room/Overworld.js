class Overworld {
  constructor(config) {
    console.log("constructed", this);
    this.element = config.element;
    this.canvas = this.element.querySelector(".game-canvas");
    this.ctx = this.canvas.getContext("2d");
    this.heroX = 40; // Initial x position of the hero
    this.heroY = 25; // Initial y position of the hero
    this.currentFrame = 0; // Current frame index
    this.frameCount = 4; // Total number of frames
    this.frameDuration = 100; // Duration of each frame in milliseconds
    this.lastFrameTime = 0; // To track the time of the last frame update
  }

  init() {
    console.log("inited", this);

    const hero = new Image();
    hero.src = "hero.png";

    const image = new Image();
    image.src = "room.png";

    const frameWidth = 21; // Width of each frame
    const frameHeight = 42; // Height of each frame

    const drawRoom = () => {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.ctx.drawImage(image, 0, 0);
    };

    const drawHero = () => {
      const sx = this.currentFrame * frameWidth; // Source x-coordinate on the sprite sheet

      // Save the canvas state before transformation
      this.ctx.save();

      // Check if the hero is moving left (reflection)
  if (this.heroX > this.targetX) {
    // Moving left: Flip horizontally
    this.ctx.scale(-1, 1);
    this.ctx.translate(-(this.heroX + frameWidth), 0); // Adjust position for the flipped coordinate system
  } else {
    // Moving right: No flip
    this.ctx.translate(this.heroX, 0); // Use normal x-coordinate
  }

  // Draw the hero frame
  this.ctx.drawImage(
    hero,
    sx, 0, frameWidth, frameHeight, // Source coordinates and dimensions on the sprite sheet
    0, this.heroY, frameWidth, frameHeight // Destination coordinates and dimensions
  );

  // Restore the canvas state after drawing
  this.ctx.restore();
};

    const animateHero = (targetX) => {
      this.targetX = targetX; // Store the target position

      const stepSize = 0.3; // Smaller step size for slower movement
      const step = targetX > this.heroX ? stepSize : -stepSize; // Determine direction

      const move = (currentTime) => {
        if (Math.abs(this.heroX - targetX) > 1) { // Continue moving until close enough
          this.heroX += step; // Move hero one step

          // Check if it's time to update the frame
          if (currentTime - this.lastFrameTime >= this.frameDuration) {
            this.lastFrameTime = currentTime;
            this.currentFrame = (this.currentFrame + 1) % this.frameCount; // Advance the animation frame
          }

          drawRoom();
          drawHero();
          requestAnimationFrame(move);
        } else {
          this.heroX = targetX; // Ensure the hero reaches the exact target position
          drawRoom();
          drawHero();
        }
      };

      requestAnimationFrame(move);
    };

    const handleCanvasClick = (event) => {
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = event.clientX / 5 - rect.left-10.5; // Adjust for canvas scaling if needed
      console.log(`Hero moving to x=${mouseX}`); // Debug: Print the target x position
      this.lastFrameTime = 0; // Reset the last frame time when starting a new animation
      animateHero(mouseX);
    };

    hero.onload = () => {
      image.onload = () => {
        this.canvas.addEventListener("click", handleCanvasClick);
        requestAnimationFrame(() => {
          drawRoom();
          drawHero();
        });
      };
    };
  }
}






// Instantiate the class and call the init method after the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  const overworld = new Overworld({
    element: document.querySelector(".game-container")
  });
  overworld.init();
});